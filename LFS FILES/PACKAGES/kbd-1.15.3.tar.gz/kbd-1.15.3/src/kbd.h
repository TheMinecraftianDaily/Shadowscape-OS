#ifndef _KBD_H
#define _KBD_H

#define attr_noreturn __attribute__ ((noreturn))
#define attr_unused __attribute__ ((unused))
#define attr_format_1_2 __attribute__ ((format (printf, 1, 2)))

#endif /* _KBD_H */
